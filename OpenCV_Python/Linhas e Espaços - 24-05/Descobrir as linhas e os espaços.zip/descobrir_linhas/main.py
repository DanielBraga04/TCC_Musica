import cv2
import numpy as np

def binarize_image(image):
    # Converter a imagem para escala de cinza
    gray_im_cropped = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Binarizar a imagem (pixels brancos tornam-se 1, pixels pretos tornam-se 0)
    binary_array = np.where(gray_im_cropped > 128, 1, 0)

    # Converter o array binário de volta para uma imagem
    reconstructed_image = np.zeros_like(gray_im_cropped, dtype=np.uint8)
    reconstructed_image[binary_array == 1] = 255

    return reconstructed_image

def encontrar_linhas_pretas(imagem, largura_minima=600):
    # Dimensões da imagem
    altura, largura = imagem.shape

    # Lista para armazenar as linhas pretas encontradas
    linhas_pretas = []

    # Percorre a imagem
    for y in range(altura):
        x = 0
        while x < largura:
            # Se o pixel for preto
            if imagem[y, x] == 0:
                # Inicia a contagem
                contador = 1
                inicio_x = x
                x += 1
                # Percorre o eixo X
                while x < largura and imagem[y, x] == 0:
                    contador += 1
                    x += 1
                # Se a largura da linha preta for maior ou igual à largura mínima
                if contador >= largura_minima:
                    # Adiciona a linha preta à lista
                    linhas_pretas.append((y, inicio_x, x-1))
                    break
            else:
                x += 1

    print("## QUAIS SÃO AS LINHAS ##")
    # Verifica se há diferença de altura de apenas um pixel entre as linhas pretas
    i = 0
    numeracao = 0
    while i < len(linhas_pretas) - 1:
        numeracao+=1
        if linhas_pretas[i+1][0] - linhas_pretas[i][0] == 1:
            print(f"{numeracao}° Linha encontrada entre Y={linhas_pretas[i][0]} e Y={linhas_pretas[i+1][0]}")
            print(f"Y={linhas_pretas[i][0]}, Início da linha em X={linhas_pretas[i][1]} e final em X={linhas_pretas[i][2]}")
            print(f"Y={linhas_pretas[i+1][0]}, Início da linha em X={linhas_pretas[i + 1][1]} e final em X={linhas_pretas[i + 1][2]}")
            print("")
            # Pula para a próxima linha após encontrar uma linha contínua
            i += 2
        else:
            print(f"{numeracao}° Linha única encontrada em Y={linhas_pretas[i][0]}, de X={linhas_pretas[i][1]} a {linhas_pretas[i][2]}")
            print("")
            i += 1

    # Se houver uma linha preta no final da imagem
    if i == len(linhas_pretas) - 1:
        print(f"{numeracao+1}° Linha única encontrada em Y={linhas_pretas[i][0]}, de X={linhas_pretas[i][1]} a {linhas_pretas[i][2]}")
        print("")


    print("## ESPAÇAMENTO ENTRE AS LINHAS ##")
    # Agrupar as linhas em grupos de 5 e calcular a diferença entre os eixos Y
    for i in range(0, len(linhas_pretas) - 1, 5):
        for j in range(i, min(i + 5, len(linhas_pretas))):
            # Se for a primeira linha do grupo
            if j == i:
                continue
            y1, _, _ = linhas_pretas[j - 1]
            y2, _, _ = linhas_pretas[j]
            # Pegar o eixo Y maior para a primeira linha do grupo e o menor para as demais
            if j == i + 1:
                y1, y2 = max(y1, y2), min(y1, y2)
            # Calcular a diferença entre os eixos Y
            diferenca_y = abs(y2 - y1)
            if diferenca_y != 1 and diferenca_y < 50:
                print(f"Espaçamento entre Y={y1} e Y={y2}: {diferenca_y-1} pixels brancos")


def main():
    # Carrega a imagem
    imagem = cv2.imread('partitura.png')

    binario = binarize_image(imagem)
    cv2.imshow("Teste Binario", binario)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Chama a função para encontrar as linhas pretas na imagem
    encontrar_linhas_pretas(binario)

if __name__ == "__main__":
    main()