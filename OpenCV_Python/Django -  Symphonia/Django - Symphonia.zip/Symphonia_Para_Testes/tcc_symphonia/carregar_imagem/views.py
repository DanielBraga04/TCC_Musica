from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from .models import Galeria

def formulario(request):
    
    if request.method == "GET":
        nomei = 'Caio'
        return  render(request, 'formulario_partitura.html', {'nome':nomei})
    elif request.method == "POST":
        partitura = request.FILES.get('partitura')
        nome = request.POST.get('nomePartitura')
        clave = request.POST.get('clave')
        tempo = request.POST.get('tempo')

        imagem1 = Galeria(partitura=partitura, nome=nome, clave=clave, tempo=tempo)

        imagem1.save()

        return HttpResponse("PARTITURA CADASTRADA!")

def carregarbanco(request):
    galeria = Galeria.objects.all()
    
    clave = request.GET.get('clave')
    tempo = request.GET.get('tempo')

    if clave and clave != '':
        galeria = galeria.filter(clave=clave)
    
    if tempo and tempo != '':
        galeria = galeria.filter(tempo=tempo)
    
    context = {
        'galeria': galeria,
        'filtro_clave': clave,
        'filtro_tempo': tempo
    }
    return render(request, 'galeria.html', context)

def excluir_partitura(request, partitura_id):
    partitura = get_object_or_404(Galeria, pk=partitura_id)
    if request.method == 'POST':
        partitura.delete()
        return redirect('carregarbanco')  # Redireciona para a página principal após excluir
    return render(request, 'excluir_partitura.html', {'partitura': partitura})

def home(request):
    return render(request, 'Symphonia.html')