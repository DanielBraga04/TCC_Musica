from django.db import models

class Galeria(models.Model):
    partitura = models.ImageField(upload_to='partituras/', default="media/mini-imagem1.png")
    nome = models.CharField(max_length=150)
    clave = models.CharField(max_length=10)
    tempo = models.CharField(max_length=10)

    def __str__(self) -> str:
        return self.nome
