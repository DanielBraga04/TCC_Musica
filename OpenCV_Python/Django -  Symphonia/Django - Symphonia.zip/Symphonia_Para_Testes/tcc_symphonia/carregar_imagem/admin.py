from django.contrib import admin
from .models import Galeria

admin.site.register(Galeria)

