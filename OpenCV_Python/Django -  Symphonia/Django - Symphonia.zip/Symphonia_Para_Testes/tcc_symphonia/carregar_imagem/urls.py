from django.urls import path
from .views import formulario
from .views import carregarbanco
from .views import home
from . import views


urlpatterns = [
    path('formulario/', formulario, name='formulario'),
    path('galeria/', carregarbanco, name='carregarbanco'),
    path('excluir/<int:partitura_id>/', views.excluir_partitura, name='excluir_partitura'),
    path('inicio/', home, name="home")
] 