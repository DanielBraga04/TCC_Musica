from django.apps import AppConfig


class CarregarImagemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'carregar_imagem'
