from django.http import HttpResponse
from django.shortcuts import render
from .models import Galeria

def formulario(request):
    
    if request.method == "GET":
        nomei = 'Caio'
        return  render(request, 'formulario_partitura.html', {'nome':nomei})
    elif request.method == "POST":
        partitura = request.FILES.get('partitura')
        nome = request.POST.get('nomePartitura')
        clave = request.POST.get('clave')
        tempo = request.POST.get('tempo')

        imagem1 = Galeria(partitura=partitura, nome=nome, clave=clave, tempo=tempo)

        imagem1.save()

        return HttpResponse()

def carregarbanco(request):
    galeria = Galeria.objects.all()
    context = {'galeria':galeria}
    return render(request, 'galeria.html', context)