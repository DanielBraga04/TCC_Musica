from django.urls import path
from .views import formulario
from .views import carregarbanco


urlpatterns = [
    path('formulario/', formulario, name='formulario'),
    path('galeria/', carregarbanco, name='carregarbanco'),
] 