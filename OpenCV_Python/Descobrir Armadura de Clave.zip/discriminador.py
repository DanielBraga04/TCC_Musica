from ram import RAM
class Discriminador:

    def __init__(self):
        self.rams = []

    def adicionar_ram(self, ram):
        self.rams.append(ram)

    def incluir_endereco(self, endereco):
        for i, end in enumerate(endereco):
            if i < len(self.rams):
                self.rams[i].bits[end] += 1
            else:
                print(f"Aviso: Endereço {end} não pôde ser incluído, RAM correspondente não encontrada.")

    def criar_e_adicionar_rams(self, total_bits, nBits):
        for i in range(total_bits):
            ram = RAM(indice=i + 1, nbits=nBits)
            self.adicionar_ram(ram)

    def imprimir_rams(self):
        for ram in self.rams:
            print("RAM: ", ram.indice)
            print("Array de Bits: ", ram.bits)
            print()

    def calcular_similaridade(self, discri_sol, discri_sol_bemol, discri_sol_2bemois):
        total_rams = len(self.rams)
        rams_similares_sol = 0
        rams_similares_sol_bemol = 0
        rams_similares_sol_2bemois = 0

        for i in range(total_rams):
            ram_trei = self.rams[i].bits
            ram_sol = discri_sol.rams[i].bits
            ram_sol_bemol = discri_sol_bemol.rams[i].bits
            ram_sol_2bemois = discri_sol_2bemois.rams[i].bits

            for j in range(len(ram_trei)):
                if ram_trei[j] != 0 and ram_sol[j] != 0:
                    rams_similares_sol += 1
                if ram_trei[j] != 0 and ram_sol_bemol[j] != 0:
                    rams_similares_sol_bemol += 1
                if ram_trei[j] != 0 and ram_sol_2bemois[j] != 0:
                    rams_similares_sol_2bemois += 1

        similaridade_sol = (rams_similares_sol / total_rams) * 100
        similaridade_sol_bemol = (rams_similares_sol_bemol / total_rams) * 100
        similaridade_sol_2bemois = (rams_similares_sol_2bemois / total_rams) * 100

        if similaridade_sol > similaridade_sol_bemol and similaridade_sol > similaridade_sol_2bemois:
            print("Resultado da Similaridade: É Clave de SOL Comum!")
        elif similaridade_sol_bemol > similaridade_sol and similaridade_sol_bemol > similaridade_sol_2bemois:
            print("Resultado da Similaridade: É Clave de SOL com 1 BEMOL!")
        elif similaridade_sol_2bemois > similaridade_sol and similaridade_sol_2bemois > similaridade_sol_bemol:
            print("Resultado da Similaridade: É Clave de SOL com 2 BEMOL!")
        else:
            print("Indeterminado!")

        print(f"SIMI SOL: {similaridade_sol:.1f}%")
        print(f"SIMI SOL COM BEMOL: {similaridade_sol_bemol:.1f}%")
        print(f"SIMI SOL COM 2 BEMOL: {similaridade_sol_2bemois:.1f}%")

    def comparar_rams(discri_teste, discri_sol, discri_fa):
        # Definindo o número de RAMs para comparar
        num_rams = 5
        for i in range(num_rams):
            ram_teste = discri_teste.rams[i].bits
            ram_sol = discri_sol.rams[i].bits
            ram_fa = discri_fa.rams[i].bits

            # Verificando se há algum número na mesma posição das RAMs
            for j in range(len(ram_teste)):
                if ram_teste[j] != 0 and ram_sol[j] != 0:
                    print(
                        f"Na RAM {i + 1} do discriminador SOL, há um número na mesma posição que na RAM do discriminador de teste.")
                if ram_teste[j] != 0 and ram_fa[j] != 0:
                    print(
                        f"Na RAM {i + 1} do discriminador FA, há um número na mesma posição que na RAM do discriminador de teste.")